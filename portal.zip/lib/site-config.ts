export const siteConfig = {
  name: "T.J. Jia",
  description: "T.J. Jia     Build. Think. Ship",
  url: "https://aibuilderlab.dev",
  author: "T.J. Jia",
  email: "jiatj@outlook.com",
  nav: [
    { href: "/tools", key: "tools" },
    { href: "/blog", key: "blog" },
    { href: "/about", key: "about" }
  ]
} as const;

export const locales = ["zh", "en"] as const;

export type Locale = (typeof locales)[number];

export const defaultLocale: Locale = "zh";
