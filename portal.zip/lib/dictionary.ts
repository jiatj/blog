import { defaultLocale, type Locale } from "@/lib/site-config";

const dictionaries = {
  zh: {
    lang: "简体中文",
    switchLabel: "切换语言",
    home: {
      eyebrow: "T.J. Jia",
      title: "T.J. Jia",
      intro:
        "Build. Think. Ship. 这里聚合我正在做的工具、实验、文章与方法论，用一个克制而稳定的入口持续发布。",
      latestPosts: "最新文章",
      latestTools: "项目",
      aboutTitle: "关于这个站",
      aboutText:
        "它不是营销页，也不是 CMS。它更像一个稳定的工作入口，承载发布、归档与持续迭代。",
      viewAllPosts: "查看全部文章",
      viewAllTools: "查看全部项目",
      enterAbout: "了解 AI Builder Lab"
    },
    nav: {
      tools: "项目",
      blog: "博客",
      about: "关于"
    },
    common: {
      backHome: "返回首页",
      readArticle: "阅读全文",
      viewProject: "查看项目",
      openProject: "打开项目",
      sourceCode: "查看源码",
      latest: "最近更新",
      noContent: "暂无内容",
      drafted: "草稿未展示",
      theme: "主题",
      light: "浅色",
      dark: "深色",
      system: "跟随系统"
    },
    blog: {
      title: "博客",
      description: "围绕 AI 构建、产品实验与长期主义创作的文章。",
      empty: "还没有可展示的文章。"
    },
    tools: {
      title: "项目",
      description: "对外发布的产品、原型与工作中正在推进的项目。",
      empty: "还没有可展示的项目。",
      status: "状态"
    },
    about: {
      title: "关于",
      intro:
        "T.J. Jia 是一个以构建、思考和持续交付为中心的个人网站入口。",
      blocks: [
        {
          title: "我在做什么",
          text: "我持续构建小而清晰的 AI 工具，并用文章记录过程中的判断、拆解和复盘。"
        },
        {
          title: "为什么做这个站",
          text: "我需要一个稳定、低噪音、适合长期迭代的入口，把内容与工具放在同一条叙事线上。"
        },
        {
          title: "联系",
          text: "如果你想交流产品、内容系统或 AI Native 工作流，可以通过邮件联系我。"
        }
      ]
    }
  },
  en: {
    lang: "English",
    switchLabel: "Switch language",
    home: {
      eyebrow: "T.J. Jia",
      title: "T.J. Jia",
      intro:
        "Build. Think. Ship. This site collects the tools, experiments, essays, and workflows I am building.",
      latestPosts: "Latest posts",
      latestTools: "Projects",
      aboutTitle: "About this site",
      aboutText:
        "It is not a marketing page or a CMS. It is a steady base for publishing, archiving, and iterating in public.",
      viewAllPosts: "See all posts",
      viewAllTools: "See all projects",
      enterAbout: "About AI Builder Lab"
    },
    nav: {
      tools: "Projects",
      blog: "Blog",
      about: "About"
    },
    common: {
      backHome: "Back to home",
      readArticle: "Read article",
      viewProject: "View project",
      openProject: "Open project",
      sourceCode: "Source code",
      latest: "Latest",
      noContent: "No content yet",
      drafted: "Draft content is hidden",
      theme: "Theme",
      light: "Light",
      dark: "Dark",
      system: "System"
    },
    blog: {
      title: "Blog",
      description: "Writing on AI building, product experiments, and long-term creative systems.",
      empty: "No published posts yet."
    },
    tools: {
      title: "Projects",
      description: "Published products, prototypes, and active projects I am building in real work.",
      empty: "No published projects yet.",
      status: "Status"
    },
    about: {
      title: "About",
      intro:
        "T.J. Jia is a personal site centered on building, thinking clearly, and shipping steadily.",
      blocks: [
        {
          title: "What I build",
          text: "I build small, clear AI tools and document the decisions, breakdowns, and lessons behind them."
        },
        {
          title: "Why this site exists",
          text: "I wanted a stable, low-noise place where tools and content can live inside the same long-term narrative."
        },
        {
          title: "Contact",
          text: "If you want to talk about products, publishing systems, or AI-native workflows, email me."
        }
      ]
    }
  }
} as const;

export function getDictionary(locale: Locale) {
  return dictionaries[locale] ?? dictionaries[defaultLocale];
}
