# AI Builder Lab Portal

一个基于 Next.js 16 的个人网站 V1，定位为“个人入口 + 工具发布站 + 博客发布层”。

## 简单说明

- 默认语言：`zh`
- 路由结构：`/{locale}/...`
- 内容来源：本地 `MDX`
- 内容目录：`content/posts/{zh,en}`、`content/tools/{zh,en}`
- 支持：博客、工具页、About、Light/Dark、SEO、sitemap、robots

## 环境搭建

建议环境：

- `Node.js >= 24`
- `npm >= 11`

安装依赖：

```bash
npm install
```

## 运行命令

本地开发：

```bash
npm run dev
```

生产构建：

```bash
npm run build
```

本地启动生产环境：

```bash
npm run start
```

## 本地写 MD 后如何发布

这个网站当前是本地文件驱动的，你在本地写好 `md` 或 `mdx` 文件后，放进对应目录即可发布到网站。

### 1. 文章放到博客目录

中文文章：

```bash
content/posts/zh/
```

英文文章：

```bash
content/posts/en/
```

### 2. 工具介绍放到工具目录

中文工具页：

```bash
content/tools/zh/
```

英文工具页：

```bash
content/tools/en/
```

### 3. 文件格式

每篇内容都需要 `frontmatter + 正文`，例如：

博客示例：

```md
---
title: 我的第一篇文章
slug: my-first-post
date: 2026-03-21
summary: 这是一篇用于测试发布流程的文章。
tags:
  - AI
  - Notes
locale: zh
draft: false
seoTitle: 我的第一篇文章
seoDescription: 这是一篇用于测试发布流程的文章。
---

这里是正文内容。
```

工具页示例：

```md
---
title: My Tool
slug: my-tool
summary: 一个简单的工具说明页。
locale: zh
draft: false
toolStatus: Beta
toolUrl: https://example.com
repoUrl: https://github.com/example/repo
seoTitle: My Tool
seoDescription: 一个简单的工具说明页。
---

这里写工具介绍、功能说明和使用方式。
```

### 4. 本地预览

写完内容后，运行：

```bash
npm run dev
```

然后打开本地网站查看页面是否生成正常。

### 5. 正式发布

提交内容后重新构建即可：

```bash
npm run build
```

如果你的部署平台会自动部署代码，只要把新内容一起提交上去，部署完成后网站就会更新。

## 部署命令

如果部署到支持 Next.js 的平台，通常使用下面的命令即可：

安装依赖：

```bash
npm install
```

构建：

```bash
npm run build
```

启动：

```bash
npm run start
```

如果部署平台本身托管运行流程，例如 Vercel，一般只需要：

- Install Command: `npm install`
- Build Command: `npm run build`
- Output: 由 Next.js 平台自动处理

## 项目结构

```text
app/                Next.js App Router 页面
components/         UI 组件
content/            本地内容源
lib/                内容读取、metadata、i18n、站点配置
doc/                需求与设计文档
```
