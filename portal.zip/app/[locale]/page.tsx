import Link from "next/link";

import { ToolCard } from "@/components/cards";
import { EmptyState } from "@/components/empty-state";
import { SectionHeading } from "@/components/section-heading";
import { getDictionary } from "@/lib/dictionary";
import { buildMetadata } from "@/lib/metadata";
import { getPosts, getTools } from "@/lib/content";
import { locales, type Locale } from "@/lib/site-config";
import { formatDate } from "@/lib/utils";

export async function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params
}: {
  params: Promise<{ locale: Locale }>;
}) {
  const { locale } = await params;
  const dict = getDictionary(locale);

  return buildMetadata({
    locale,
    title: dict.home.title,
    description: dict.home.intro,
    path: ""
  });
}

export default async function HomePage({
  params
}: {
  params: Promise<{ locale: Locale }>;
}) {
  const { locale } = await params;
  const dict = getDictionary(locale);
  const [posts, tools] = await Promise.all([getPosts(locale), getTools(locale)]);

  return (
    <main className="space-y-20 pb-10">
      <section className="rounded-[var(--radius-hero)] border border-[color:color-mix(in_srgb,var(--border-soft)_86%,transparent)] bg-[color:color-mix(in_srgb,var(--hero-surface)_96%,transparent)] px-6 py-8 shadow-[var(--shadow)] sm:px-10 sm:py-10 lg:px-12 lg:py-12">
        <div className="lg:grid lg:min-h-[24rem] lg:grid-cols-[minmax(0,36rem)_1fr] lg:items-center">
          <div className="max-w-[32rem]">
            <SectionHeading
              eyebrow={dict.home.eyebrow}
              title={dict.home.title}
              description={dict.home.intro}
              level="hero"
            />
            <div className="mt-7 flex flex-col gap-4 border-t border-[color:color-mix(in_srgb,var(--border-faint)_90%,transparent)] pt-5 sm:max-w-[27.5rem]">
              <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center sm:gap-3.5">
                <Link
                  className="inline-flex min-w-40 whitespace-nowrap items-center justify-center rounded-[var(--radius-pill)] border border-transparent bg-[var(--foreground)] px-5 py-3 text-sm font-medium text-[color:var(--background)] transition hover:opacity-92"
                  href={`/${locale}/tools`}
                >
                  {dict.home.viewAllTools}
                </Link>
                <Link
                  className="inline-flex items-center border-b border-[var(--link-underline)] pb-0.5 text-sm font-medium text-[var(--muted-foreground)] transition hover:border-[var(--link-underline-hover)] hover:text-[var(--foreground)]"
                  href={`/${locale}/blog`}
                >
                  {dict.home.viewAllPosts} {"->"}
                </Link>
              </div>
              <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-[var(--muted-foreground)]">
                <Link
                  className="inline-flex items-center border-b border-transparent pb-0.5 transition hover:border-[var(--link-underline)] hover:text-[var(--foreground)]"
                  href={`/${locale}/about`}
                >
                  {dict.home.enterAbout}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="grid gap-14 lg:grid-cols-[1.04fr,0.96fr] lg:items-start">
        <div className="space-y-5">
          <div className="max-w-xl">
            <p className="text-[0.66rem] uppercase tracking-[0.28em] text-[var(--muted-foreground-soft)]">
              {dict.common.latest}
            </p>
            <h2 className="mt-2 text-[1.6rem] font-semibold leading-[1.12] tracking-[-0.04em] sm:text-[1.9rem]">
              {dict.home.latestTools}
            </h2>
          </div>
          {tools.length ? (
            <div className="grid gap-3.5">
              {tools.slice(0, 2).map((tool) => (
                <ToolCard key={tool.slug} locale={locale} tool={tool} />
              ))}
            </div>
          ) : (
            <EmptyState message={dict.tools.empty} />
          )}
        </div>

        <div className="space-y-12 pt-1 lg:pl-4">
          <section>
            <p className="text-[0.68rem] uppercase tracking-[0.3em] text-[var(--muted-foreground-soft)]">
              {dict.home.latestPosts}
            </p>
            <div className="mt-5 space-y-7">
              {posts.length ? (
                posts.slice(0, 3).map((post) => (
                  <article
                    key={post.slug}
                    className="border-t border-[var(--border-faint)] pt-7 first:border-t-0 first:pt-0"
                  >
                    <p className="text-[0.68rem] uppercase tracking-[0.22em] text-[var(--muted-foreground-soft)]">
                      {formatDate(post.date ?? "", locale)}
                    </p>
                    <h2 className="mt-3 text-[1.45rem] font-semibold leading-[1.22] tracking-[-0.03em] sm:text-[1.55rem]">
                      {post.title}
                    </h2>
                    <p className="mt-3 max-w-xl text-[1rem] leading-8 text-[color:color-mix(in_srgb,var(--muted-foreground)_92%,var(--foreground))]">
                      {post.summary}
                    </p>
                    <Link
                      className="mt-4 inline-block border-b border-[var(--link-underline)] pb-0.5 text-sm text-[var(--foreground)] transition hover:border-[var(--link-underline-hover)] hover:text-[var(--accent-ink)]"
                      href={`/${locale}/blog/${post.slug}`}
                    >
                      {dict.common.readArticle} {"->"}
                    </Link>
                  </article>
                ))
              ) : (
                <p className="text-sm text-[var(--muted-foreground)]">{dict.blog.empty}</p>
              )}
            </div>
          </section>

          <section className="border-t border-[var(--border-faint)] pt-9">
            <p className="text-[0.68rem] uppercase tracking-[0.3em] text-[var(--muted-foreground-soft)]">
              {dict.home.aboutTitle}
            </p>
            <p className="mt-4 max-w-xl text-[1rem] leading-8 text-[color:color-mix(in_srgb,var(--muted-foreground)_92%,var(--foreground))]">
              {dict.home.aboutText}
            </p>
            <Link
              className="mt-5 inline-block border-b border-[var(--link-underline)] pb-0.5 text-sm text-[var(--foreground)] transition hover:border-[var(--link-underline-hover)] hover:text-[var(--accent-ink)]"
              href={`/${locale}/about`}
            >
              {dict.home.enterAbout} {"->"}
            </Link>
          </section>
        </div>
      </section>
    </main>
  );
}
