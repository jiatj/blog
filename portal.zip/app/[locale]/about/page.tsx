import { SectionHeading } from "@/components/section-heading";
import { getDictionary } from "@/lib/dictionary";
import { buildMetadata } from "@/lib/metadata";
import { siteConfig, locales, type Locale } from "@/lib/site-config";

export async function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({
  params
}: {
  params: Promise<{ locale: Locale }>;
}) {
  const { locale } = await params;
  const dict = getDictionary(locale);

  return buildMetadata({
    locale,
    title: dict.about.title,
    description: dict.about.intro,
    path: "/about"
  });
}

export default async function AboutPage({
  params
}: {
  params: Promise<{ locale: Locale }>;
}) {
  const { locale } = await params;
  const dict = getDictionary(locale);

  return (
    <main className="space-y-10">
      <section className="rounded-[1.75rem] border border-[var(--border-soft)] bg-[color:color-mix(in_srgb,var(--card-strong)_88%,transparent)] px-6 py-10 shadow-[var(--shadow-soft)] sm:px-10 sm:py-12">
        <SectionHeading title={dict.about.title} description={dict.about.intro} level="page" />
      </section>
      <section className="grid gap-5 lg:grid-cols-3">
        {dict.about.blocks.map((block) => (
          <article
            key={block.title}
            className="rounded-[1.5rem] border border-[var(--border-soft)] bg-[color:color-mix(in_srgb,var(--card-strong)_92%,transparent)] p-7"
          >
            <h2 className="text-[1.8rem] font-semibold leading-[1.24] tracking-[-0.03em]">
              {block.title}
            </h2>
            <p className="mt-4 text-[1.02rem] leading-8 text-[var(--muted-foreground)]">{block.text}</p>
          </article>
        ))}
      </section>
      <section className="rounded-[1.5rem] border border-[var(--border-soft)] bg-[color:color-mix(in_srgb,var(--card-strong)_92%,transparent)] p-6">
        <p className="text-sm text-[var(--muted-foreground)]">{siteConfig.email}</p>
      </section>
    </main>
  );
}
