import { notFound } from "next/navigation";

import { renderMdx, getPostBySlug, getPosts } from "@/lib/content";
import { getDictionary } from "@/lib/dictionary";
import { buildMetadata } from "@/lib/metadata";
import { formatDate } from "@/lib/utils";
import { locales, type Locale } from "@/lib/site-config";

export async function generateStaticParams() {
  const all = await Promise.all(locales.map(async (locale) => ({ locale, posts: await getPosts(locale) })));
  return all.flatMap(({ locale, posts }) => posts.map((post) => ({ locale, slug: post.slug ?? "" })));
}

export async function generateMetadata({
  params
}: {
  params: Promise<{ locale: Locale; slug: string }>;
}) {
  const { locale, slug } = await params;
  const post = await getPostBySlug(locale, slug);

  if (!post) {
    return {};
  }

  return buildMetadata({
    locale,
    title: post.seoTitle ?? post.title ?? "",
    description: post.seoDescription ?? post.summary ?? "",
    path: `/blog/${slug}`
  });
}

export default async function BlogDetailPage({
  params
}: {
  params: Promise<{ locale: Locale; slug: string }>;
}) {
  const { locale, slug } = await params;
  const post = await getPostBySlug(locale, slug);
  const dict = getDictionary(locale);

  if (!post) {
    notFound();
  }

  const content = await renderMdx(post.content);

  return (
    <main className="mx-auto w-full max-w-[54rem] space-y-10 px-1 pb-4">
      <article className="rounded-[1.75rem] border border-[var(--border-soft)] bg-[color:color-mix(in_srgb,var(--card-strong)_90%,transparent)] px-6 py-10 shadow-[var(--shadow-soft)] sm:px-10 sm:py-12">
        <p className="text-xs uppercase tracking-[0.24em] text-[var(--muted-foreground-soft)]">
          {formatDate(post.date ?? "", locale)}
        </p>
        <h1 className="mt-4 text-4xl font-semibold leading-[1.14] tracking-[-0.035em] sm:text-[3.35rem]">
          {post.title}
        </h1>
        <p className="mt-6 max-w-3xl text-lg leading-9 text-[var(--muted-foreground)]">
          {post.summary}
        </p>
        <div className="mt-6 flex flex-wrap gap-2">
          {(post.tags ?? []).map((tag) => (
            <span
              key={tag}
              className="rounded-full bg-[var(--accent-soft)] px-3 py-1 text-xs text-[var(--accent-ink)]"
            >
              {tag}
            </span>
          ))}
        </div>
        <div className="prose mt-12 max-w-none">{content}</div>
      </article>
      <p className="px-2 text-sm text-[var(--muted-foreground)]">{dict.common.drafted}</p>
    </main>
  );
}
