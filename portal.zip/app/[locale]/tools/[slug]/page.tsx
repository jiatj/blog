import { notFound } from "next/navigation";

import { getToolBySlug, getTools, renderMdx } from "@/lib/content";
import { getDictionary } from "@/lib/dictionary";
import { buildMetadata } from "@/lib/metadata";
import { locales, type Locale } from "@/lib/site-config";

export async function generateStaticParams() {
  const all = await Promise.all(locales.map(async (locale) => ({ locale, tools: await getTools(locale) })));
  return all.flatMap(({ locale, tools }) => tools.map((tool) => ({ locale, slug: tool.slug ?? "" })));
}

export async function generateMetadata({
  params
}: {
  params: Promise<{ locale: Locale; slug: string }>;
}) {
  const { locale, slug } = await params;
  const tool = await getToolBySlug(locale, slug);

  if (!tool) {
    return {};
  }

  return buildMetadata({
    locale,
    title: tool.seoTitle ?? tool.title ?? "",
    description: tool.seoDescription ?? tool.summary ?? "",
    path: `/tools/${slug}`
  });
}

export default async function ToolDetailPage({
  params
}: {
  params: Promise<{ locale: Locale; slug: string }>;
}) {
  const { locale, slug } = await params;
  const tool = await getToolBySlug(locale, slug);
  const dict = getDictionary(locale);

  if (!tool) {
    notFound();
  }

  const content = await renderMdx(tool.content);

  return (
    <main className="mx-auto w-full max-w-[68rem]">
      <article className="rounded-[1.75rem] border border-[var(--border-soft)] bg-[color:color-mix(in_srgb,var(--card-strong)_90%,transparent)] px-6 py-10 shadow-[var(--shadow-soft)] sm:px-10 sm:py-12">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="max-w-3xl">
            <p className="text-xs uppercase tracking-[0.24em] text-[var(--muted-foreground-soft)]">
              {tool.toolStatus ?? dict.tools.status}
            </p>
            <h1 className="mt-4 text-4xl font-semibold leading-[1.14] tracking-[-0.035em] sm:text-[3.2rem]">
              {tool.title}
            </h1>
            <p className="mt-6 text-lg leading-9 text-[var(--muted-foreground)]">{tool.summary}</p>
          </div>
          {tool.toolUrl ? (
            <a
              className="rounded-full bg-[var(--foreground)] px-5 py-3 text-sm text-[var(--surface)] transition hover:opacity-92"
              href={tool.toolUrl}
              rel="noreferrer"
              target="_blank"
            >
              {dict.common.openProject}
            </a>
          ) : null}
        </div>
        <div className="mt-8 flex flex-wrap gap-4 text-sm">
          {tool.repoUrl ? (
            <a
              className="text-[var(--muted-foreground)] transition hover:text-[var(--accent-ink)]"
              href={tool.repoUrl}
              rel="noreferrer"
              target="_blank"
            >
              {dict.common.sourceCode}
            </a>
          ) : null}
        </div>
        <div className="prose mt-10 max-w-none">{content}</div>
      </article>
    </main>
  );
}
